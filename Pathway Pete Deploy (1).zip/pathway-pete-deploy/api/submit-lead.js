// Upserts a HubSpot contact by email, then logs each pathway as a note
// Needs a Private App token with scopes: crm.objects.contacts.write + crm.objects.notes.write
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const TOKEN = process.env.HUBSPOT_PRIVATE_TOKEN;
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${TOKEN}`
  };

  try {
    const { firstName, lastName, email, org, jobRole, industry, pathwayTitle, pathwaySummary } = req.body;

    // ── 1. Upsert contact by email ──────────────────────────────────────────
    // Existing contact → updates properties. New email → creates contact.
    const upsertRes = await fetch('https://api.hubapi.com/crm/v3/objects/contacts/batch/upsert', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        inputs: [{
          idProperty: 'email',
          id: email,
          properties: {
            firstname: firstName || '',
            lastname:  lastName  || '',
            email:     email     || '',
            company:   org       || '',
            jobtitle:  jobRole   || '',
          }
        }]
      })
    });

    const upsertData = await upsertRes.json();

    if (!upsertRes.ok) {
      console.error('HubSpot upsert error:', upsertData);
      return res.status(200).json({ ok: true, warning: 'Contact upsert failed' });
    }

    const contactId = upsertData.results?.[0]?.id;
    if (!contactId) {
      console.error('No contact ID returned:', upsertData);
      return res.status(200).json({ ok: true, warning: 'No contact ID' });
    }

    // ── 2. Log pathway as a note on the contact ─────────────────────────────
    // Every pathway submission appears in the contact's activity timeline.
    // Multiple submissions = multiple notes. No history is ever lost.
    const noteBody = [
      `📋 PATHWAY BUILDER SUBMISSION`,
      ``,
      `Title: ${pathwayTitle || 'Untitled pathway'}`,
      `Learner industry: ${industry || 'Not specified'}`,
      `Organisation: ${org || 'Not specified'}`,
      `Requestor: ${firstName} ${lastName}${jobRole ? ` — ${jobRole}` : ''}`,
      ``,
      `── PATHWAY CONTENT ──`,
      pathwaySummary || 'No summary available',
      ``,
      `Submitted via Bodyswaps Pathway Builder`,
    ].join('\n');

    const noteRes = await fetch('https://api.hubapi.com/crm/v3/objects/notes', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        properties: {
          hs_timestamp:  String(Date.now()),
          hs_note_body:  noteBody,
        },
        associations: [{
          to:    { id: contactId },
          types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 202 }]
        }]
      })
    });

    if (!noteRes.ok) {
      const noteErr = await noteRes.json();
      console.error('Note creation error:', noteErr);
      return res.status(200).json({ ok: true, warning: 'Note creation failed' });
    }

    return res.status(200).json({ ok: true });

  } catch (err) {
    console.error('submit-lead error:', err);
    return res.status(200).json({ ok: true, warning: String(err.message) });
  }
}
