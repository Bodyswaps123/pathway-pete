# Bodyswaps Pathway Builder — Deployment Guide

## What's in this package

```
pathway-pete-deploy/
├── public/
│   └── index.html          ← The full app (HTML + CSS + JS)
├── api/
│   ├── generate.js         ← Proxies Claude API (keeps your key secret)
│   └── submit-lead.js      ← Sends lead data to HubSpot
├── vercel.json             ← Vercel routing config
└── README.md
```

---

## Step 1 — Deploy to Vercel (10 mins, free)

### Option A — No GitHub needed (drag & drop)

1. Go to [vercel.com](https://vercel.com) and sign up / log in
2. Click **"Add New Project"** → **"Deploy from CLI"** or use the Vercel CLI:
   ```
   npm i -g vercel
   cd pathway-pete-deploy
   vercel
   ```
3. Follow the prompts — accept all defaults
4. Your app will be live at something like `pathway-pete-abc123.vercel.app`

### Option B — Via GitHub (recommended for easy updates)

1. Create a new GitHub repo, upload this folder
2. Go to [vercel.com](https://vercel.com) → **Add New Project** → Import from GitHub
3. Select your repo → click **Deploy**

---

## Step 2 — Add environment variables

In Vercel dashboard → your project → **Settings → Environment Variables**, add:

| Variable | Value | Notes |
|---|---|---|
| `ANTHROPIC_API_KEY` | `sk-ant-...` | Get from console.anthropic.com |
| `HUBSPOT_PRIVATE_TOKEN` | `pat-na1-...` | See Step 3 below |

Then go to **Deployments → Redeploy** to apply them.

---

## Step 3 — Create a HubSpot Private App token (5 mins)

This lets the app create/update contacts and log pathway notes to their timeline.

1. In HubSpot → **Settings (cog icon) → Integrations → Private Apps**
2. Click **Create a private app**
3. Name it "Pathway Pete"
4. Under **Scopes**, enable:
   - `crm.objects.contacts.read`
   - `crm.objects.contacts.write`
   - `crm.objects.notes.write`
5. Click **Create app** → copy the token (starts with `pat-na1-...`)
6. Add it as `HUBSPOT_PRIVATE_TOKEN` in Vercel env vars

**What this does:**
- New email → creates a contact in HubSpot
- Existing email → updates their record (no duplicates)
- Every pathway generated → logged as a note on their contact timeline
- Build 3 pathways? You'll see 3 notes. No history lost.

---

## Step 4 — Custom domain (optional, 5 mins)

To use `pathway.bodyswaps.co`:

1. In Vercel → your project → **Settings → Domains**
2. Add `pathway.bodyswaps.co`
3. Vercel will give you a DNS record to add — go to wherever you manage bodyswaps.co DNS
4. Add a **CNAME** record: `pathway` → `cname.vercel-dns.com`
5. Wait a few minutes — done ✅

---

## Step 5 — Embed in HubSpot (optional)

If you also want a link/button on a HubSpot landing page:

Add a button or CTA in HubSpot that points to `https://pathway.bodyswaps.co`

**Do not use an iframe** — the standalone URL gives a much better mobile experience.

---

## Updating the app

If you used GitHub: edit `public/index.html`, push → Vercel auto-deploys.

If you used drag & drop: run `vercel --prod` from the folder again.

---

## Testing checklist

- [ ] Form loads on mobile (iOS Safari + Android Chrome)
- [ ] Step 1 validation blocks empty fields
- [ ] Pathway generates successfully (check browser console for errors)
- [ ] Lead appears in HubSpot after pathway is generated
- [ ] "Create in Bodyswaps Go" button visible on result screen

---

## Support

API keys and credentials to gather before starting:
- Anthropic API key: https://console.anthropic.com
- HubSpot Portal ID: HubSpot → Settings → Account Setup → Account
- HubSpot Form ID: HubSpot → Marketing → Forms → your form → embed code
